#load the necessary libraries
library(dplyr)
library(ggplot2)
library(maps)
library(plyr)
library(gridExtra)
library(reshape2)
library(rgl)
library(shiny)
library(sunburstR)




SEP <- "\t"
SEP2 <- ","



R_DATA_GENERAL <- "C:/Users/soyeb/OneDrive/Documents/20255901_TOLUWALASE_SOYEBO_codes/"

#######################################
# 
# LOAD DATA
#######################################

message("loading data...")

crime_df <- read.table(paste(R_DATA_GENERAL,"USA_crime_guns_data.csv", sep=""),
                       quote="\"", header=T, comment.char="", sep=SEP2)
usa_map <- map_data("state")


#######################################
# 
# DATA MANIPULATION
#######################################

message("filtering data... ")

#
# dropping additional column and creating new column
crime_df <- subset(crime_df, select = -X)
crime_df <- mutate(crime_df, other_v_crime = violent - (murder + robbery))


#creating a subset data set for year 1999
crime_df_99 <- subset(crime_df, year == 1999)
#creating a subset data set for year 1995
crime_df_95 <- subset(crime_df,year==1995)

# transforming the data to the required format to merge with map data
rownames(crime_df_99) <- crime_df_99$state
crime_df_99 <- mutate(crime_df_99, state = tolower(state))
row.names(crime_df_99) <- tolower(row.names(crime_df_99))
head(crime_df_99)
crime_df_99map <- merge(usa_map, crime_df_99, by.x="region", by.y="state")
crime_df_99map <- arrange(crime_df_99map, group,order)


# creating an additional columnn that represents binary information of law clmn 
crime_df <- mutate (crime_df, check = ifelse(law == "yes", 1, 0))
# calculating the total amount of states with the law imposed for each year
crime_law_summary <- crime_df %>%
  group_by(year) %>%
  mutate(total_check = sum(check)) %>%
  distinct(year,total_check)

#need to calculate quantile values, as they need to be removed
quant_i95 <- quantile(crime_df$income, 0.95)
quant_i0.05 <- quantile(crime_df$income, 0.05)
quant_d95 <- quantile(crime_df$density, 0.95)
quant_d0.05 <- quantile(crime_df$density, 0.05)

# getting the top and bottom 3 of the income group for 1999

top3_df_income <- crime_df %>%
  filter(year == 1999, income <= quant_i95, income >= quant_i0.05) %>%
  arrange(desc(income)) %>%
  slice(1:3)
btm3_df_income <- crime_df %>%
  filter (year == 1999, income <= quant_i95, income >= quant_i0.05) %>%
  arrange(income) %>%
  slice(1:3)

# create a subset for each of these states, so they can be plotted (lowest)
msp_df <- subset(crime_df, state == "Mississippi")
wv_df <- subset(crime_df, state == "West Virginia")
nm_df <- subset(crime_df, state == "New Mexico")
# create a subset for each of these states, so they can be plotted (highest)
wsh_df <- subset(crime_df, state == "Washington")
cali_df <- subset(crime_df, state == "California")
v_df <- subset(crime_df, state == "Virginia")

#getting the top and bottom 3 of the population density group for 1999
top3_df_pd <- crime_df %>%
  filter(year == 1999, density <= quant_d95, density >= quant_d0.05) %>%
  arrange(desc(density)) %>%
  slice(1:3)
btm3_df_pd <- crime_df %>%
  filter (year == 1999, density <= quant_d95, density >= quant_d0.05) %>%
  arrange(density) %>%
  slice(1:3)

# create a subset for each of these states, so they can be plotted (lowest)
m_df <- subset(crime_df, state == "Montana")
nd_df <- subset(crime_df, state == "North Dakota")
sd_df <- subset(crime_df, state == "South Dakota")
# create a subset for each of these states, so they can be plotted (highest)
mas_df <- subset(crime_df, state == "Massachusetts")
con_df <- subset(crime_df, state == "Connecticut")
mar_df <- subset(crime_df, state == "Maryland")

#################################################
# 
# MORE DATA MANIPULATION -EXPLORATORY QUESTIONS
##################################################
#

#transforming the data set, to plot all information on the same line graph
msp_df_select <- select(msp_df, year,violent,murder,robbery,other_v_crime)
msp_df_melt <- melt(msp_df_select, id = "year")

wv_df_select <- select(wv_df, year,violent,murder,robbery,other_v_crime)
wv_df_melt <- melt(wv_df_select, id = "year")

nm_df_select <- select(nm_df,year,violent,murder,robbery,other_v_crime)
nm_df_melt <- melt(nm_df_select, id = "year")

wsh_df_select <- select(wsh_df,year,violent,murder,robbery,other_v_crime)
wsh_df_melt <- melt(wsh_df_select, id = "year")

cali_df_select <- select(cali_df,year,violent,murder,robbery,other_v_crime)
cali_df_melt <- melt(cali_df_select, id = "year")

v_df_select <- select(v_df,year,violent,murder,robbery,other_v_crime)
v_df_melt <- melt(v_df_select, id = "year")

# transforming the data to focus on specific columns
crime_df_99_select <- select(crime_df_99, violent,density,income)

# function from the pairs help page
panel.cor <- function(x, y, digits = 2, prefix = "", cex.cor, ...)
{
  par(usr = c(0, 1, 0, 1))
  r <- abs(cor(x, y))
  txt <- format(c(r, 0.123456789), digits = digits)[1]
  txt <- paste0(prefix, txt)
  if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
  text(0.5, 0.5, txt, cex = cex.cor * r)
}

# function from the pairs help page
panel.hist <- function(x, ...)
{
  usr <- par("usr")
  par(usr = c(usr[1:2], 0, 1.5) )
  h <- hist(x, plot = FALSE)
  breaks <- h$breaks; nB <- length(breaks)
  y <- h$counts; y <- y/max(y)
  rect(breaks[-nB], 0, breaks[-1], y, col = "cyan", ...)
}

# function from R graphics cookbook
panel.lm <- function(x,y,col = par("col"), bg = NA, pch = par("pch"),
                     cex = 1, col.smooth = "red", ...) {
  points(x,y, pch = pch, col = col, bg = bg, cex = cex)
  abline(stats::lm(y~x), col=col.smooth,...)
}


#######################################
# 
# BASIC ANALYSIS AND VISUALIZATION
#######################################
#

message("IQ1: Did the majority of states have the law included by 1999, and did
        these states have the law imposed at the time")


g1 <- ggplot(crime_df_99, aes(map_id = state, fill=violent)) + 
  geom_map(map = usa_map, colour="black") + 
  scale_fill_gradient2(low="#559999", mid="grey90", high="#BB650B",
                       midpoint=median(crime_df_99$violent)) + 
  expand_limits(x=usa_map$long, y = usa_map$lat) + coord_map("polyconic")


g2 <- ggplot(crime_df_99, aes(map_id = state, fill=law)) +
  geom_map(map = usa_map, color = "black") +
  expand_limits(x = usa_map$long, y = usa_map$lat) + coord_map("polyconic") +
  scale_fill_manual(values = c("red", "green"), name = "law") 

grid.arrange(g1,g2, ncol=2)


message("IQ2: what year did most states have the gun law imposed?")
ggplot(crime_law_summary, aes(x=year, y=total_check)) +
  geom_bar(stat="identity",fill="lightblue", colour="black") + 
  labs(title = "Number of States with crime law by year ", x="year", y="number of states")


message("IQ3: How did violent crime rate change according to the 1999 household
        income and population densityt for each state")
msp_plot <- ggplot(data=msp_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="Mississipi",y="violent_count") +
    theme(plot.title = element_text(hjust = 0.5))

wv_plot <- ggplot(data=wv_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="West Virginia",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

nm_plot <-  ggplot(data=nm_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="New Mexico",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

wsh_plot <-  ggplot(data=wsh_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="Washington",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

cali_plot <- ggplot(data=cali_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="California",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

v_plot <- ggplot(data=v_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="Virginia",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

grid.arrange(msp_plot,wv_plot,nm_plot,wsh_plot,cali_plot,v_plot, ncol=3, nrow=3)


message("IQ4: How effective was the gun law in 1999, in reducing violent crimes?")
m_plot <- ggplot(data=m_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="Montana",y="violent_count") +  
  theme(plot.title = element_text(hjust = 0.5))

nd_plot <- ggplot(data=nd_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="North Dakota",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

sd_plot <- ggplot(data=sd_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="South Dakota",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

mas_plot <- ggplot(data=mas_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="Massachusetts",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

con_plot <- ggplot(data=con_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="Connecticut",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

mar_plot <- ggplot(data=mar_df, aes(x=year, y=violent)) +
  geom_line() + labs(title="Maryland",y="violent_count") +
  theme(plot.title = element_text(hjust = 0.5))

grid.arrange(m_plot,nd_plot,sd_plot,mas_plot,con_plot,mar_plot, ncol=3, nrow=3)



#######################################
# EXPLORATORY ANALYSIS AND VISUALIZATION
# 
#######################################
#

message("RQ1:  How does the distribution of states with gun law compare between 1995 and 1999?") 

p <- ggplot(crime_df_99, aes(x=law, y=violent))
g3 <- p + geom_violin(trim=FALSE) + geom_boxplot(width=.1, fill="black",
                                                 outlier.colour = NA) +
  stat_summary(fun.y=median,geom="point", fill="white", shape = 21, size=2.5) +
  labs(title = "Distribution in 1999") + 
  theme(plot.title = element_text(hjust = 0.5))

q <- ggplot(crime_df_95, aes(x=law, y=violent))
g4 <- q + geom_violin(trim=FALSE) + geom_boxplot(width=.1, fill="black",
                                               outlier.colour = NA) +
  stat_summary(fun.y=median,geom="point", fill="white", shape = 21, size=2.5) +
  labs(title = "distribution in 1995") +
  theme(plot.title = element_text(hjust = 0.5))
grid.arrange(g3,g4,ncol=2)


message("RQ2: How do the different types of violent crime change over the years?") 

g5 <- ggplot(msp_df_melt,aes(x=year, y=value,colour=variable)) + geom_line() + 
  labs(title = "Mississipi") + theme(plot.title = element_text(hjust = 0.5))

g6 <- ggplot(wv_df_melt,aes(x=year, y=value,colour=variable)) + geom_line() + 
  labs(title = "West Virginia") + theme(plot.title = element_text(hjust = 0.5))

g7 <- ggplot(nm_df_melt,aes(x=year, y=value,colour=variable)) + geom_line() + 
  labs(title = "New Mexico") + theme(plot.title = element_text(hjust = 0.5))

g8 <- ggplot(wsh_df_melt,aes(x=year, y=value,colour=variable)) + geom_line() + 
  labs(title = "Washington") + theme(plot.title = element_text(hjust = 0.5))

g9 <- ggplot(cali_df_melt,aes(x=year, y=value,colour=variable)) + geom_line() + 
  labs(title = "California" ) + theme(plot.title = element_text(hjust = 0.5))

g10 <- ggplot(v_df_melt,aes(x=year, y=value,colour=variable)) + geom_line() + 
  labs(title = "Virginia") + theme(plot.title = element_text(hjust = 0.5))

grid.arrange(g5,g6,g7, g8, g9,g10)


message("RQ3:  explore how violent crime, population density and hosuehold relate with eachother") 

pairs(crime_df_99_select[,1:3],pch=".",upper.panel=panel.cor, 
      diag.panel=panel.hist, lower.panel=panel.lm)


message("RQ4: How significant is the gun law in reducing violent crime ") 

ggplot(crime_df_99,aes(x=violent, y=reorder(state, violent))) + 
  geom_segment(aes(yend=state), xend=0, colour="grey50") + 
  geom_point(aes(size = density, colour=law)) + 
         scale_colour_brewer(palette="Set1", limits=c("yes", "no"), guide="none") +
         theme_bw() + theme(panel.grid.major.y = element_blank()) + 
         facet_grid(law ~ ., scales ="free_y",space="free_y")
    

##########################################################
# 
# EXPERIMENTING WITH OPENGL LIBRARY AND INBUILT D3 LIBRARIES
########################################################
#

# plotting an interactive 3d scatter plot
plot3d(crime_df_99$violent, crime_df_99$density,crime_df_99$income, type="s", size=0.75, lit=FALSE)

#attempting to use the inbuilt d3 libraries for R studio
sunburst(msp_df)

dev.off()



