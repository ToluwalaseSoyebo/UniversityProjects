import nltk
nltk.download('stopwords')
nltk.download('omw-1.4') 
from nltk.tokenize import word_tokenize
from nltk.tokenize import sent_tokenize 
import random 
import Intent_matching_classifier 
import pickle
import warnings
import about_bot
from finance_health_check import take_user_query
from about_bot import response
from about_finance import finance_information
from about_health import health_information
from identity_management import initalise_name
from small_talk import small_talk
warnings.filterwarnings('ignore')

words = pickle.load(open('words.pkl', 'rb'))
labels = pickle.load(open('labels.pkl', 'rb'))
data = pickle.load(open('data.pkl', 'rb'))
model = Intent_matching_classifier.dtree_model

GREET_INPUTS = ["hello", "hi", "sup", "how you doing", "hey", "Good morning", "Good afternoon", "Good evening"]
GREET_RESPONSE = ["hi", "hey", "hey there", "Hello, glad to meet you"]
POSITIVE_USER_RESPONSE = ["yes","yeah", "si", "ja"] 
NEGATIVE_USER_RESPONSE = ["no", "don't worry", "nein"]

#greeting function. 
def greeting(sentence):
    for word in sentence.split():
        if word.lower() in GREET_INPUTS:
            return random.choice(GREET_RESPONSE)

user_name = ""

def check_username(user_name): 
    if user_name == "":
        user_name_sentence = input("Al: Sorry I have done all the talking, could I get your name \nuser: ")
        user_name = initalise_name(user_name_sentence) 
        return user_name

def say_hello(user_name):
    print('Al: Hello', user_name, 'how can I help you')
    activate()

def activate():
    flag = True
    while(flag == True):
        type_response = input("user: ") 
        integer_returned, similairity_score = take_user_query(type_response)
        count = 0
        if similairity_score == 0: 
            if count < 4:
                print("Al: Sorry could you rephrase that: ") 
                continue
            else:
                print("Hey sorry I cannot help ")
                break 
        else:
            if integer_returned == 1:
                print("Welcome to the finance page ")
                new_flag = True
                while(new_flag == True):
                    user_input = input("Al: Please ask a question \nuser: ")
                    user_input.lower()
                    if user_input == "exit":
                        print("now leaving facts page function")
                        break
                    else:
                        response = finance_information(user_input)
                    print(response) 
            elif integer_returned == 2:
                print("Welcome to the health page where today's topic is Sickle cell")
                new_flag = True
                while(new_flag == True):
                    user_input = input("Al: Please ask a question \nuser:  ")
                    user_input.lower()
                    if user_input == "exit":
                        print("now leaving facts page function")
                        break                         
                    else:
                        response = health_information(user_input)
                    print(response)
            else:
                print("Have a good day!")
                break 
 
#type_response = [type_response]
#result = Intent_matching_classifier.predicting(type_response)
#print(result) 
#answer = Intent_matching_classifier.generate_intent(result)
if __name__ == "__main__": #start of the program
    flag = True
    print("Al: Hello I'm Al your virtual assistant, to leave just type Exit, at any point, to have small talk just type talk")
    while(flag==True): 
        if user_name == "" :
            user_response = input("user: ")
        else:
            user_response = input(user_name, ": ")
        user_response = user_response.lower()
        if(user_response!="exit"):
            if (user_response =="thanks" or user_response == "thank you"):
                answer = input("Al: You're welcome, please let me know if you need anything else, by typing yes or no\nUser: ")
                if (answer in POSITIVE_USER_RESPONSE):
                    user_enetered_name= check_username(user_name)
                    say_hello(user_enetered_name) 
                else:
                    print("Al: hope I was helpful")
                    flag = False 
            else:
                if(greeting(user_response)!=None):
                    print("Al: " +greeting(user_response))
                elif(user_response == "talk"):
                    print("Al: so you just want to talk - sure, chat away ") 
                    user_response = input("User: " )
                    print("Al: ",small_talk(user_response)) 
                elif(user_response == "next"):
                    user_enetered_name= check_username(user_name) 
                    say_hello(user_enetered_name)        
                else: 
                    print("Al: ", end= "")
                    print(response(user_response))
                    about_bot.sent_tokens.remove(user_response)
        else:
            flag = False
            print("Al: See you next time") 




