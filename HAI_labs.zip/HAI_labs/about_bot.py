import nltk
nltk.download('stopwords')
nltk.download('omw-1.4') 
from nltk.tokenize import word_tokenize
from nltk.tokenize import sent_tokenize 
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.stem.snowball import PorterStemmer
import string 
import warnings
warnings.filterwarnings('ignore')

file = open('HAI_documents_corpus\explanation.txt', 'r', errors = 'ignore') 
raw_file = file.read()
raw_file = raw_file.lower() 
sent_tokens = sent_tokenize(raw_file) 
word_tokens = word_tokenize(raw_file) 

lemmatiser = WordNetLemmatizer()
p_stemmer = PorterStemmer()

def LemTokens(tokens): 
    return [p_stemmer.stem(token) for token in tokens]

remove_punct_dict = dict((ord(punct),None) for punct in string.punctuation) 

def LemNormalize(text):
    return LemTokens(word_tokenize(text.lower().translate(remove_punct_dict))) 


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity 

def response(user_response): 
    chatbot_response = "" 
    sent_tokens.append(user_response) 
    TfidfVec = TfidfVectorizer(tokenizer=LemNormalize, stop_words="english") 
    tfidf_matrix = TfidfVec.fit_transform(sent_tokens) 
    tfidf_userinput_matrix = tfidf_matrix[-1]
    vals = cosine_similarity(tfidf_userinput_matrix,tfidf_matrix) 
    idx = vals.argsort()[0][-2] 
    flat = vals.flatten()  
    flat.sort()
    req_tfidf = flat[-2] 
    if(req_tfidf == 0): 
        chatbot_response = chatbot_response + "I am sorry! I do not understand can you try rephrasing" 
        return chatbot_response 
    else:
        chatbot_response = chatbot_response+sent_tokens[idx] 
        return chatbot_response